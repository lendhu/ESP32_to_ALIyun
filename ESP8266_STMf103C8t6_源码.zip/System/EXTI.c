#include "stm32f10x.h"                  // Device header

#define EXTI_Periph RCC_APB2Periph_GPIOA
#define EXTI_Port GPIOA
#define EXTI_Pin_Num GPIO_Pin_5
#define GPIO_PortSourceGPIO GPIO_PortSourceGPIOA
#define EXTI_GPIO GPIO_PinSource5
#define EXTI_LineX EXTI_Line5

int Count;
void Interrupt_init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	RCC_APB2PeriphClockCmd(EXTI_Periph,ENABLE);		//����ʱ��GPIO��AFIO
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode= GPIO_Mode_IPU;					//����������
	GPIO_InitStruct.GPIO_Pin= EXTI_Pin_Num;
	GPIO_InitStruct.GPIO_Speed= GPIO_Speed_50MHz;
	GPIO_Init(EXTI_Port,&GPIO_InitStruct);
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIO,GPIO_PinSource5);	//����AFIO�ⲿ�ж�����ѡ��
	
	EXTI_InitTypeDef EXTI_InitStruct;
	EXTI_InitStruct.EXTI_Line= EXTI_LineX;						//ѡ���ж���
	EXTI_InitStruct.EXTI_LineCmd= ENABLE;
	EXTI_InitStruct.EXTI_Mode= EXTI_Mode_Interrupt;				//�ж�ģʽ
	EXTI_InitStruct.EXTI_Trigger= EXTI_Trigger_Falling;			//�½��ش���
	EXTI_Init(&EXTI_InitStruct);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);				//�������ȼ����飺��ռ���ȼ����ռ���ȼ�(per/sub)
	
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannel= EXTI9_5_IRQn;				//MD�е��ܶ�
	NVIC_InitStruct.NVIC_IRQChannelCmd= ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority= 1;		
	NVIC_InitStruct.NVIC_IRQChannelSubPriority= 1;
	NVIC_Init(&NVIC_InitStruct);
}

void EXTI9_5_IRQHandler(void)
{
	if(EXTI_GetFlagStatus(EXTI_LineX)==SET)//SET�ǣ�RESET����
	{
		
		Count++;
		EXTI_ClearITPendingBit(EXTI_LineX);
	}



}

