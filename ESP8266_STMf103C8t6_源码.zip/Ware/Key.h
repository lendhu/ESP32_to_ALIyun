#ifndef __KEY_H__
#define __KEY_H__

void Key_Init(void);
uint8_t Key_Scan(GPIO_TypeDef* GPIOX,uint16_t GPIO_Pin);
#endif

