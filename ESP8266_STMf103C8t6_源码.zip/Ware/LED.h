#ifndef __LED_H__
#define __LED_H__

void LED_Init(void);
void LED_Control(uint16_t Num);
#endif

