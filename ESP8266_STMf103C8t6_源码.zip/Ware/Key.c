#include "stm32f10x.h"                  // Device header
#include "Delay.h"

#define Key_Port GPIOA
#define Key_Pin_Num GPIO_Pin_5

#define Key_ON 1
#define Key_OFF 0
void Key_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure_A;
	GPIO_InitStructure_A.GPIO_Mode= GPIO_Mode_IPU;//��������
	GPIO_InitStructure_A.GPIO_Pin= Key_Pin_Num;
	GPIO_InitStructure_A.GPIO_Speed= GPIO_Speed_50MHz;
	GPIO_Init(Key_Port,&GPIO_InitStructure_A);//PA8

}

uint8_t Key_Scan(GPIO_TypeDef* GPIOX,uint16_t GPIO_Pin)
{
	if(GPIO_ReadInputDataBit(GPIOX,GPIO_Pin)==Key_ON)
	{
		Delay_ms(50);
		while(GPIO_ReadInputDataBit(GPIOX,GPIO_Pin)==Key_ON);
		Delay_ms(50);
		return Key_ON;
	}else 
	{
		return Key_OFF;
	}

}
