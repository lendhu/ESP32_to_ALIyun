#include "stm32f10x.h"                  // Device header
#include "delay.h"
#include <stdio.h>
#include "LED.h"
void ESP8266_Init(void)
{
		//1.����ESP8266
		printf("AT+RST\r\n");
		Delay_s(2);
		//2.����ģʽ
		printf("AT+CWMODE=1\r\n");
		Delay_s(1);
		//3.���Ӱ�����
		printf("AT+CIPSNTPCFG=1,8,\"ntp1.aliyun.com\"\r\n");
		Delay_s(1);
		//4.����WIFI
		printf("AT+CWJAP=\"acc\",\"123456789\"\r\n");
		Delay_s(3);
		Delay_s(3);
		//5.�Ϻ�
		printf("AT+MQTTUSERCFG=0,1,\"NULL\",\"ESP8266&ieuiXEHiFbL\",\"6be7ca27fcc02d75348a445818f704dc3ede6942e9cb7a5e6ee28fb79853549f\",0,0,\"\"\r\n");
		Delay_s(1);
		printf("AT+MQTTCLIENTID=0,\"ieuiXEHiFbL.ESP8266|securemode=2\\,signmethod=hmacsha256\\,timestamp=1709013953246|\"\r\n");
		Delay_s(1);
		printf("AT+MQTTCONN=0,\"iot-06z00chbff5sfds.mqtt.iothub.aliyuncs.com\",1883,1\r\n");
		Delay_s(3);
		Delay_s(3);
		Delay_s(3);
		//6.����
		printf("AT+MQTTSUB=0,\"/ieuiGXSvy9P/ESP8266/user/get\",1\r\n");
		Delay_s(3);
		GPIO_SetBits(GPIOA, GPIO_Pin_0);
		Delay_ms(500);
}

void ESP8266_Send(float data)
{
		printf("AT+MQTTPUB=0,\"/ieuiXEHiFbL/ESP8266/user/update\",\"{\\\"temp\\\":%f}\",1,0\r\n",data);
		Delay_s(3);
}

